var assert = require('assert');

describe('sample', function () {
  it('should pass', function () {
    assert(true, 'not passed!');
  });
});
