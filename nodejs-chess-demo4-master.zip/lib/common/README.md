# Folder for code that can be used for both client and server
